package unibo.btlib;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.util.UUID;

public final class ConnectToBluetoothServerTask extends ConnectionTask {

    private BluetoothSocket btSocket = null;

    //Ultimo parametro oggetto del tipo dell'interfaccia.
    //uuid  --> id del canale.
    public ConnectToBluetoothServerTask(final BluetoothDevice serverBtDevice, final UUID uuid, final EventListener eventListener){
        try {
            btSocket = serverBtDevice.createRfcommSocketToServiceRecord(uuid); //istanza della socket.
            this.eventListener = eventListener;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected Integer doInBackground(Void... unused) {
        try {
            btSocket.connect();
        } catch (IOException e) {
            e.printStackTrace();
            try {
                btSocket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            return CONNECTION_CANCELED;
        }

        //Se connessione a buon termine allora creiamo il canale di comunicazione.
        connectedChannel = new RealBluetoothChannel(btSocket);

        return CONNECTION_DONE;
    }
}
