package unibo.btlib.utils;

public class C {
    public static final String LIB_TAG = "BluetoothLib";

    public class channel {
        public static final int MESSSAGE_RECEIVED = 0;
        public static final int MESSAGE_SENT = 1;
    }

    public class message {
        public static final char MESSAGE_TERMINATOR = '\n';
    }
}
