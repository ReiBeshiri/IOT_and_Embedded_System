package unibo.btlib;

import android.os.AsyncTask;

public abstract class ConnectionTask extends AsyncTask<Void, Void, Integer> {

    static final int CONNECTION_DONE = 1;
    static final int CONNECTION_CANCELED = 2;

    BluetoothChannel connectedChannel;
    EventListener eventListener;

    //Eseguito sul MainThread (può modificare l'interfaccia) alla fine del doInBackground().
    //result --> risultato della doInBackground().
    @Override
    protected void onPostExecute(Integer result) {
        switch (result){
            case CONNECTION_DONE:
                if(eventListener != null){
                    eventListener.onConnectionActive(connectedChannel);
                }
                break;

            case CONNECTION_CANCELED:
                if(eventListener != null){
                    eventListener.onConnectionCanceled();
                }
                break;
        }
    }

    //Viene utilizzata dal Connection task o da chi la estende, di conseguenza anche dal nostro async task, essendo
    //il suo tipo un'estensione di questa classe.
    //--> Saranno poi da definire nell'implementazione.
    public interface EventListener{
        void onConnectionActive(final BluetoothChannel channel);
        void onConnectionCanceled();
    }
}
