package unibo.btclient;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.NumberPicker;
import android.widget.TextView;
import java.util.UUID;
import unibo.btclient.utils.C;
import unibo.btlib.BluetoothChannel;
import unibo.btlib.ConnectionTask;
import unibo.btlib.RealBluetoothChannel;
import unibo.btlib.ConnectToBluetoothServerTask;
import unibo.btlib.BluetoothUtils;
import unibo.btlib.exceptions.BluetoothDeviceNotFound;

public class MainActivity extends AppCompatActivity {

    private BluetoothChannel btChannel;

    //Questa activity viene richiamata all'inizio e quando l'activity viene stoppata e killata dal sistema e l'utente la richiede nuovamente.
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Restituisce l'unica istanza del bluetooth.
        final BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();

        //Controlla che il bt sia attivo e abilitato.
        if(btAdapter != null && !btAdapter.isEnabled()){
            //Nel caso in cui il bt non sia abilitato si richiede l'attivazione al sistema.
            //Questa activity richiata è diversa da tutte le altre , infatti restituisce un risltato.
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), C.bluetooth.ENABLE_BT_REQUEST);
        }

        initUI();
    }

    private void initUI() {
        findViewById(R.id.btnConnect).setOnClickListener(v -> {
            try {
                connectToBTServer();
            } catch (BluetoothDeviceNotFound bluetoothDeviceNotFound) {
                bluetoothDeviceNotFound.printStackTrace();
            }
        });

        findViewById(R.id.btnStartIrrig).setOnClickListener(v -> {
            btChannel.sendMessage("start-" + Integer.toString(((NumberPicker) findViewById(R.id.flow)).getValue()));
        });

        findViewById(R.id.btnStopIrrig).setOnClickListener(v -> {
            btChannel.sendMessage("stop");
        });

    }

    //Chiamata quando l'activity non viene stoppata --> non utilizzata per un po di tempo.
    protected void onStop() {
        super.onStop();
        btChannel.sendMessage("die");
        btChannel.close();
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, @Nullable final Intent data) {
        if(requestCode == C.bluetooth.ENABLE_BT_REQUEST && resultCode == RESULT_OK){
            Log.d(C.APP_LOG_TAG, "Bluetooth enabled!");
        }

        if(requestCode == C.bluetooth.ENABLE_BT_REQUEST && resultCode == RESULT_CANCELED){
            Log.d(C.APP_LOG_TAG, "Bluetooth not enabled!");
        }
    }

    private void connectToBTServer() throws BluetoothDeviceNotFound {
        //Acccoppiamento non significa comunicazione,significa solo che i due dipositivi si conoscono e si sono scambiati gli ID.
        final BluetoothDevice serverDevice = BluetoothUtils.getPairedDeviceByName(C.bluetooth.BT_DEVICE_ACTING_AS_SERVER_NAME);

        //UUID utilizzato per identificare univocamante il canale di comunicazione.
        //Client e server devono conoscere l'uid per comunicare.
        //N.B: Per i dispositivi embedded o per quelle per cui non è possisbile effettuare l'accoppiamento (pairing) è necessario usare
        //un UUID di default. --> 00001101-0000-1000-8000-00805F9B34FB
        final UUID uuid = BluetoothUtils.getEmbeddedDeviceDefaultUuid();

        //Ultimo parametro oggetto del tipo dell'interfaccia.
        AsyncTask<Void, Void, Integer> execute = new ConnectToBluetoothServerTask(serverDevice, uuid, new ConnectionTask.EventListener() {

            //Metodi dell'interfaccia che somo definiti con una classe anonima, e vengono richiamati dalla OnPostExecute() dell'async task.
            //Di conseguenza possono agire sull'interfaccia utente essendo eseguiti dal main thread.
            @Override
            public void onConnectionActive(final BluetoothChannel channel) {

                ((TextView) findViewById(R.id.lblStatus)).setText(String.format("Status : connected to server on device %s",
                        serverDevice.getName()));

                findViewById(R.id.btnConnect).setEnabled(false);

                //Assegnazione del realchannel al nostro canale che ci viene restituito al termine della doInBackground, essendo questi metodi chiamati nella onPostExecute().
                btChannel = channel;

                //registrazione dei listener al nostro canale.
                //I metodi devono essere istanziati mediante una classe anonima.
                //Questi metodi vengono eseguiti dal Listener creato con la classe anonima,
                //ma vengono notificati dal worker thread definito in RealBTChannel,
                //La notifica è relativa a un evento avvenuto sul canale BT. (ricezione, invio).
                btChannel.registerListener(new RealBluetoothChannel.Listener() {
                    @Override
                    public void onMessageReceived(String receivedMessage) {
                        ((TextView) findViewById(R.id.log)).append(String.format("> [RECEIVED from %s] %s\n",
                                btChannel.getRemoteDeviceName(),
                                receivedMessage));
                    }

                    @Override
                    public void onMessageSent(String sentMessage) {
                        ((TextView) findViewById(R.id.log)).append(String.format("> [SENT to %s] %s\n",
                                btChannel.getRemoteDeviceName(),
                                sentMessage));
                    }
                });

                btChannel.sendMessage("init");
            }

            @Override
            public void onConnectionCanceled() {
                ((TextView) findViewById(R.id.lblStatus)).setText(String.format("Status : unable to connect, device %s not found!",
                        C.bluetooth.BT_DEVICE_ACTING_AS_SERVER_NAME));
            }
        }).execute();
    }
}
