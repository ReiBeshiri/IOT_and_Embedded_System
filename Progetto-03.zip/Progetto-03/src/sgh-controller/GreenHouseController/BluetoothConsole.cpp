#include "BluetoothConsole.h"
#include "SoftwareSerial.h"
#include "Arduino.h"

BluetoothConsole::BluetoothConsole(SoftwareSerial *c){ //nel setup della creazione dei task crea il software serial che poi lo passo al bluetooth
  this->channel = c;  //alla creazione del bluetooth gli passo anche il channel per la comunicazione seriale software (PIN 2-4)
}

void BluetoothConsole::init(){
  channel->begin(9600);
}

String BluetoothConsole::btread(){
  String msg = "";
  //vede se il canale aperto ha un messaggio nel buffer
  if (channel->available()) {
    while (channel->available()) {
      char ch = (char) channel->read();
      if (ch == '\n'){
        return msg;    
      } else {
        msg += ch;      
      }
    }
  }
  return msg;
}

void BluetoothConsole::btsend(String u){
  channel->println(u);
}
