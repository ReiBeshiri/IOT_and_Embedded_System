#ifndef __FEEDBACKSTATE__
#define __FEEDBACKSTATE__

#include "Led.h"
#include "SharedState.h"

class Feedback {

public:
  Feedback(Led* l1, Led* l2, Led* lm, SharedState* s);
  void showCurrentState();  //switch led1 e ledm
  void showPumpFlow(); //pwm led2

private:
  Led* led1;
  Led* led2;
  Led* ledm;
  SharedState* shared;
  
};
#endif
