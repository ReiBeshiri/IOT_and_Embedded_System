#include "Arduino.h"
#include "UserConsole.h"

UserConsole::UserConsole(Receiver* r, Sender* s){
  this->receiver = r;
  this->sender = s;
}

void UserConsole::sendMsg(String s){
  sender->sendMsg(s);
}

int UserConsole::receiveMsg(){
  return receiver->receive();
}
