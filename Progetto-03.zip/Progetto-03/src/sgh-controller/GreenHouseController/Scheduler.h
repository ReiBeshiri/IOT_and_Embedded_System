#ifndef __SCHEDULER__
#define __SCHEDULER__ 

#include "Timer.h"
#include "Task.h"
#include <ArduinoSTL.h>
#include <vector>

class Scheduler {
public:
	void init(int basePeriod);
	virtual void addTask(Task* task);
	virtual void schedule();

private:
	int basePeriod;
	int nTask;
	std::vector<Task*> taskList;
	Timer* timer;
	void sleep();
};

#endif
