#ifndef __REMOTE__
#define __REMOTE__

#include "Task.h"
#include "SharedState.h"
#include "Feedback.h"
#include "BluetoothConsole.h"
#include "UserConsole.h"

class Remote: public Task {
public:
  void step();
  Remote(SharedState* s, Feedback* f, BluetoothConsole* bt, UserConsole* u);
  
private:
  enum State{ OFF, ACTIVE };
  State state = OFF;
  SharedState* shared;
  Feedback* feedback;
  BluetoothConsole* bluetooth;
  UserConsole* userConsole;
};

#endif
