#ifndef __MODMANAGER__
#define __MODMANAGER__

#include "Task.h"
#include "SharedState.h"
#include "Feedback.h"
#include "ProximitySensorImpl.h"
#include "BluetoothConsole.h"
#include "UserConsole.h"

class ModManager: public Task {
public:
  void step();
  ModManager(SharedState* s, ProximitySensorImpl* ps, Feedback* f, BluetoothConsole* bt, UserConsole* u);
  
private:
  enum State{ AUTO, MANUAL };
  State state = AUTO;
  SharedState* shared;
  ProximitySensorImpl* proxsensor;
  Feedback* feedback;
  BluetoothConsole* bluetooth;
  UserConsole* userConsole;
  const long engageTime = 1000000;
  const long leaveTime = 2000000;
  long t;
  bool resetTime = false;
};

#endif
