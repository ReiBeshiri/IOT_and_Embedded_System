#include <ArduinoSTL.h>
#include <vector>
#include "Scheduler.h"
#include "Arduino.h"

void Scheduler::init(int basePeriod) {
	this -> basePeriod = basePeriod;
  timer = new Timer();
	timer -> setupPeriod(basePeriod);
	nTask = 0;
}

void Scheduler::addTask(Task* task) {
	taskList.push_back(task);
	nTask++;
}

void Scheduler::schedule() {
	timer -> waitForNextTick();
	for(int i = 0; i < nTask; i++) {
    if (taskList[i]->updateAndCheckTime(basePeriod)){
      taskList[i] -> step();
    }
	}
}
