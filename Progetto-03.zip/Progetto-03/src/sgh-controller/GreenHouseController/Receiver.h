#ifndef __RECEIVER__
#define __RECEIVER__

#include "Arduino.h"

class Receiver{
public:
  int receive();
};


#endif
