#include "Irrigation.h"
#include "Arduino.h"
#include "Define.h"

String stringStart = "Irrigazione iniziata";
String stringStop = "Irrigazione terminata";

Irrigation::Irrigation(SharedState* s, Feedback* f, ServoMotorImpl* sm, BluetoothConsole* bt, UserConsole* u){
  this->shared = s;
  this->feedback = f;
  this->servo = sm;
  this->bluetooth = bt;
  this->userConsole = u;
}

void Irrigation::step(){
  switch(state){
    case OFF:
      if(shared->getU() < shared->getUmin() && !shared->isManual()){ //se sono in AUTO mode e U < Umin attivo l'irrigazione
        shared->startIrrigating();
      }
      if(shared->isIrrigating()){ //Sia che l'irrogazione sia partita da comando remoto o automaticamente avvia il tempo di conteggio della pompa aperta.
        state = ON;
        t = micros();
        servo->on();
        servo->setPosition(SERVO_OPEN);
        userConsole->sendMsg(stringStart);
      }
    break;

    case ON:
      feedback->showPumpFlow();
      userConsole->sendMsg("Irrigating... Pump flow: " + String(shared->getY()) + " l/m");
      //Se siamo in modalità automatica e abbiamo superato DeltaU o è passato il temopo massimo allora spegniamo l'irrigazione.
      if(shared->getU() >= shared->getUmin() + shared->getDeltaU() && !shared->isManual()) {  
        shared->stopIrrigating();
      } else if(micros() - t > shared->getTimeExceeded() && !shared->isManual()) {
        shared->stopIrrigating();
        userConsole->sendMsg("Irrigation time exceeded! --> STOP IRRIGATION.");
      } 
      
      //Nel caso in cui da remoto ci hanno disattivato l'irrogazione, o in automatico il sistema ha stopp. l'irrigazione, riportiamo il task a off.
      if(!shared->isIrrigating()){
        state = OFF;
        servo->setPosition(SERVO_CLOSE);
        //servo->off();
        shared->setY(0);  // chiudo la pompa dell'acqua
        feedback->showPumpFlow(); //per visualizzare la portata sul led2
        userConsole->sendMsg(stringStop + "--> durata: " + (micros() - t) / 1000000 + " sec");
      }
    break;
  }
}
