#ifndef __IRRIGATION__
#define __IRRIGATION__

#include "Task.h"
#include "SharedState.h"
#include "ServoMotorImpl.h"
#include "Feedback.h"
#include "BluetoothConsole.h"
#include "UserConsole.h"

class Irrigation: public Task {
public:
  void step();
  Irrigation(SharedState* s, Feedback* f, ServoMotorImpl* sm, BluetoothConsole* bt, UserConsole* u);
  
private:
  long t;
  enum State{ OFF, ON };
  State state = OFF;
  SharedState* shared;
  Feedback* feedback;
  ServoMotorImpl* servo;
  BluetoothConsole* bluetooth;
  UserConsole* userConsole;
};

#endif
