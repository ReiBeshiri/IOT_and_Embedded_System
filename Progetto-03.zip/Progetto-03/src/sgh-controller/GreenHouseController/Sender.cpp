#include "Sender.h"
#include "Arduino.h"

void Sender::sendMsg(String s) {
  Serial.println(s); //il messaggio che si deve inviare al pc
}
