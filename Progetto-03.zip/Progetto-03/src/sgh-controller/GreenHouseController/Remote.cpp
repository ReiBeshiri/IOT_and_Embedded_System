#include "Remote.h"
#include "Arduino.h"

Remote::Remote(SharedState* s, Feedback* f, BluetoothConsole* bt, UserConsole* u){
  this->shared = s;
  this->feedback = f;
  this->bluetooth = bt;
  this->userConsole = u;
}

void Remote::step(){
  switch(state){
    case OFF:
      if(shared->isManual()){
        state = ACTIVE;
      }
    break;

    case ACTIVE:
      if(!shared->isManual()) {  //se il modManager mi cambia la modalità stoppo l'irrigazione
        shared->stopIrrigating();
        shared->setY(0);
        state = OFF;
      } else { 
        //Controllo comandi ricevuti da bt (da remoto).
        String msg = bluetooth->btread();
        if(msg != "") {
          int index = msg.indexOf("-");
          if(msg == "init") {
            shared->startPairing(); 
           } else if(msg == "die") {
            shared->stopPairing();
           } else if(msg == "stop") {  
            // stop irrigazione
            shared->stopIrrigating(); 
            userConsole->sendMsg("Command received from BT channel: " + msg);
           } else if(index != -1){ 
            // start irrigazione
            userConsole->sendMsg("START");
            shared->startIrrigating();
            shared->setY(msg.substring(index+1).toInt());
            userConsole->sendMsg("Command received from BT channel: " + msg);
           }
         } else {
          //Nel caso in cui siamo nella modalità manuale, abbiamo un dispositivo accoppiato e
          //non abbiamo ricevuto messaggi, allora inviamo l'umidità aggiornata alla mobile app.
          if(shared->isPaired()) {
            bluetooth->btsend(String(shared->getU()));
          }
        }
      }
      break;
  }
}
