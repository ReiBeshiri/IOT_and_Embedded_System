#include "Receiver.h"
#include "Arduino.h"
#include "Define.h"

int Receiver::receive() {
  String str = "";
  while (Serial.available()) {
    char ch = (char) Serial.read();
    if (ch == '\n'){
      return str.toInt();   
    } else {
      str += ch;      
    }
  }
  return -1;
}
