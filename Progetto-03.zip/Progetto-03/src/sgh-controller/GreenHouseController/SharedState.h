#ifndef __SHARED_STATE__
#define __SHARED_STATE__

#include "Arduino.h"

class SharedState {

private:
  bool manual;
  bool irrigationOn;
  bool remote;
  bool pair;
  int Umin;
  int U;
  long timeExceeded;
  int Y;
  float dist;
  int receivedInt;
  String msg;
  int deltaU;
  
public:
  
  SharedState(int U, int Umin, long timeExceeded, float dist, int delta){
    this->U = U;
    this->Umin = Umin;
    this->timeExceeded = timeExceeded;
    this->Y = 0;
    this->dist = dist;
    this->msg = String();
    this->deltaU = delta;
    manual = false;
    irrigationOn = false;
    pair = false;
  }

  int getU() { return U; }
  int getUmin() { return Umin; }
  int getY() { return Y; }
  float getDist() { return dist; }
  long getTimeExceeded() { return timeExceeded; }
  char getInt() { return receivedInt; }
  String getMsg() { return msg; }
  int getDeltaU() { return deltaU; }

  bool isManual() { return manual; }
  void changeMode() { manual = !manual; }
  bool isPaired() { return pair; }
  void startPairing() { pair = true; } //Viene settato un dispositivi quando accoppiato.
  void stopPairing() { pair = false; } //Viene settato un dispositivi quando dissociato.

  bool isIrrigating() { return irrigationOn; }
  void startIrrigating() { irrigationOn = true; }
  void stopIrrigating() { irrigationOn = false; }
  
  void setY(int y) { Y = y; }
  void setU(int u) { U = u; }
  void setUmin(int um) { Umin = um; }
  void setInt(int i) { receivedInt = i; }
  void setMsg(String c) { msg = c; }

};

#endif
