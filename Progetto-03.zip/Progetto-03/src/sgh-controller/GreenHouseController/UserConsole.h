#ifndef __USERCONSOLE__
#define __USERCONSOLE__

#include "Receiver.h"
#include "Sender.h"
#include "Arduino.h"

class UserConsole{
  
public:
  UserConsole(Receiver* r, Sender* s);
  void sendMsg(String s);
  int receiveMsg();
  
private:
  Receiver* receiver;
  Sender* sender;
};

#endif
