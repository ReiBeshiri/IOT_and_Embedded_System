#ifndef __BLUETOOTH__
#define __BLUETOOTH__

#include "SoftwareSerial.h"
#include "SharedState.h"
#include <Wire.h>

class BluetoothConsole{
public:
  BluetoothConsole(SoftwareSerial *c);
  String btread();
  void btsend(String u);
  void init();

private:
  SoftwareSerial *channel;//comm seriale pin 2-4, messo come puntatore sia channel che nel costruttore quando ci passano la Softwareserial
};

#endif
