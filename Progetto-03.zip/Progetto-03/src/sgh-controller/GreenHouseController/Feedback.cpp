#include "Feedback.h"
#include "Arduino.h"
#include "Define.h"

Feedback::Feedback(Led* l1, Led* l2, Led* lm, SharedState* s){
  this->led1 = l1;
  this->led2 = l2;
  this->ledm = lm;
  this->shared = s;
}

void Feedback::showCurrentState(){
  if(shared->isManual()) {
    led1->switchOff();
    ledm->switchOn();
  } else {
    ledm->switchOff();
    led1->switchOn();
  }
}

void Feedback::showPumpFlow(){
  if(shared->isIrrigating()) {
    led2->setIntensity(map(shared->getY(), 0, YMAX, 0, 255));
  } else {
    led2->setIntensity(0);
  }
}
