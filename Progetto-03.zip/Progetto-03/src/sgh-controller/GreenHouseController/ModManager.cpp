#include "ModManager.h"
#include "ProximitySensorImpl.h"
#include "Arduino.h"
#include "ProximitySensorImpl.h"
#include "Define.h"

String stringMan = "Modalità Manuale";
String stringAuto = "Modalità Automatica";

ModManager::ModManager(SharedState* s, ProximitySensorImpl* ps, Feedback* f, BluetoothConsole* bt, UserConsole* u){
  this->shared = s;
  this->proxsensor = ps;
  this->feedback = f;
  this->bluetooth;
  this->userConsole = u;
}

void ModManager::step(){
  int hum = userConsole->receiveMsg();
  if(hum != -1 && hum != shared->getU()) {
    shared->setU(hum);
    userConsole->sendMsg("Humidity received: " + String(hum));
  }
  
  feedback->showCurrentState();//fai vedere il led 1 o led m acceso
  switch(state){
    case AUTO:
        if(shared->getU() <= YMIN){
          shared->setY(YMAX);
        } else if(shared->getU() <= YMED && shared->getU() > YMIN){
          shared->setY(YMED);
        } else if(shared->getU() < YMAX && shared->getU() > YMED){
          shared->setY(YMIN);
        }
        ///se sono abbastanza vicino da attivare la modalità manulale
        if(proxsensor->getDistance() < shared->getDist()) {
          if(resetTime) {
            resetTime = false;
            t = micros();
          }
          if(micros() - t > engageTime) {
            shared->changeMode();
            state = MANUAL;
            userConsole->sendMsg("Switched to manual");

            //Se l'utente si avvicina allora il sistema va in modalità manuale e viene anche stoppata l'eventuale irrigazione.
            if(shared->isIrrigating()) {
                shared->stopIrrigating();
                userConsole->sendMsg("System goes to manual mode --> STOP IRRIGATION.");
            }
          }
        } else {
          resetTime = true;
        }
    break;

    case MANUAL:
      //se sono abbastanza lontano da attivare la modalità auto
       if(proxsensor->getDistance() > shared->getDist()) {
          if(resetTime){
            resetTime = false;
            t = micros();
          }
          if(micros() - t > leaveTime) {
            shared->changeMode();
            state = AUTO;
            userConsole->sendMsg("Switched to auto");
          }
        } else {
          resetTime = true;
        }
    break;
  }
}
