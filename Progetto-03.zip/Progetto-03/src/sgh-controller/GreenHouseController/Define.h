#define L1 12
#define L2 5
#define LM 13
#define PIN_ECHO_SONAR 7
#define PIN_TRIG_SONAR 8
#define TX_BT 2
#define RX_BT 4
#define PINSERVO 6
#define UMIN 30
#define YMIN 10
#define YMED 20
#define YMAX 30
#define TIMEEXCEEDED 5000000
#define DIST 0.3
#define DELTAU 5
#define SERVO_CLOSE 0
#define SERVO_OPEN 180

#define SCHED_PERIOD 100
#define MOD_PERIOD   100
#define IRR_PERIOD   100
#define REM_PERIOD   100

/*
 * I periodi sono stati settati in questo modo perchè:
 * --> Lo scheduler deve avere periodo uguale MCD degli altri.
 * --> Il ModManager invece con 500 millisec, per non perderci eventi, abbiamo deciso di scegliere questo periodo, perchè ci sembrava consono nell'invio di messaggi al server
 *     (periodo non troppo basso). Essendo il task che gestisce le modalità del sistema a nostro avviso doveva avere la priorità massima (primo nella cosa) e anche il periodo min
 *     per non perdere eventi.
 * --> All'irrigation task invece abbiamo asseganto sempre il periodo minimo, perchè supponendo di essere in un sistema reale, con una serra molto estesa e delle pompe a grande
 *     portata, anche la perdita di un evento quele il cambio di modalità del sistema, oppure la ricezione di una umidità suffucientemente alta all'interruzione dell'erogazione 
 *     avrebbe portato  grandi sprechi.
 * --> Anche per il Remote Task abbiamo optato per il peirodo minimo, in modo che l'utente abbia un feedback/controllo immediato del/dal sistema. Anche in questo caso essendo il 
 *     ModManager a rilevare le distanze e avendo questo task prioritò uguale, non ci perdiamo eventi quali l'avvicinamento dell'utente.
 *     
 *     
 * SCELTE PROGETTUALI:
 * --> Quando il sistema sta irrigando e si avvicina un utente cabiando la modalità, allora l'irrigazione automatica viene stoppata per essere controllata da remoto.
 * --> Per quanto rigiarda il ritorno dalla modalità manuale alla modalità automatica abbiamo optato per una scelta simile a quella della macchina del caffè, controllando che non
 *     sia rilevato un utente nelle vicinanze per un numero opportuno di secondi.
 * --> Abbiamo deciso di mantenere lo stato di accoppiamento dei due dipositivi (connessi o non) tra mobile app e arduino, mandnado 2 messaggi speciali di init e die dalla mobile app
 *     a inizio e fine comunicazione.
 * 
 */
