#ifndef __SENDER__
#define __SENDER__

#include "Arduino.h"

class Sender{
public:
  void sendMsg(String s);
};

#endif
