package events;

/**
 * Base interface for events.
 *
 */
public interface Event { }
