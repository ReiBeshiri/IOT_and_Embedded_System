package events;

public class SerialMessage implements Event {
	
	private final String msg;
	
	public SerialMessage(final String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return this.msg;
	}
}
