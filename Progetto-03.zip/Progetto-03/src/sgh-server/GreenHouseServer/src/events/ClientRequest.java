package events;

import java.net.DatagramPacket;
import channel.SocketChannel;

public class ClientRequest implements Event {
	
	private final SocketChannel channel;
	private final DatagramPacket pkt;
	
	public ClientRequest(final DatagramPacket pkt, final SocketChannel channel) {
		this.channel = channel;
		this.pkt = pkt;
	}
	
	public SocketChannel getSocket() {
		return this.channel;
	}
	
	public DatagramPacket getPacket() {
		return this.pkt;
	}
}
