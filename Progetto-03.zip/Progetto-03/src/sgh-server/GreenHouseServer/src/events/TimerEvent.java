package events;

public class TimerEvent implements Event { }
