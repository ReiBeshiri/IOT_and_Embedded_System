package observable;

import java.util.LinkedList;

import agent.Observer;
import events.Event;

public abstract class BasicObservable implements Observable {
	
	private final LinkedList<Observer> observers;
	
	protected BasicObservable(){
		observers = new LinkedList<Observer>();
	}
	
	protected void notifyEvent(final Event ev) {
		synchronized (observers){
			for (final Observer obs: observers){
				obs.notifyEvent(ev);
			}
		}
	}

	public void addObserver(final Observer obs) {
		synchronized (observers){
			observers.add(obs);
		}
	}

	public void removeObserver(final Observer obs) {
		synchronized (observers){
			observers.remove(obs);
		}
	}

}
