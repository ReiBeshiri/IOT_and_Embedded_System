package observable;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import events.TimerEvent;

/**
 * Observable timer che genera eventi ogni periodo.
 *
 */
public class TimerObservable extends BasicObservable {
	
	private Runnable tickTask;
	private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	private ScheduledFuture<?> tickHandle;
	
	public TimerObservable() {
		tickTask = () -> {
			notifyEvent(new TimerEvent());
		};
	}
	
	/**
	 * Start generating tick event
	 * 
	 * @param period period in milliseconds
	 */
	public synchronized void start(final long period){
		//Il tempo viene schedulato ad un ratio prefissato che è pari al periodo, e dopo tot secondi
		//verrà poi eseguito l'hander che genererà e notificherà l'evento all'agente.
		tickHandle = scheduler.scheduleAtFixedRate(tickTask, 0, period, TimeUnit.MILLISECONDS);	    
	}
	
	/**
	 * Stop generating tick event
	 * 
	 * @param period period in milliseconds
	 */
	public synchronized void stop(){
		if (tickHandle != null){
			tickHandle.cancel(false);
			tickHandle = null;
		}
	}
	
}
