package observable;

import agent.Observer;

public interface Observable {
	
	void addObserver(final Observer obs);

	void removeObserver(final Observer obs);
}
