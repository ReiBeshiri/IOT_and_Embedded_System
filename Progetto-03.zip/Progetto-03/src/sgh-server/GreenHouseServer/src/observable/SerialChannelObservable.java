package observable;

import channel.SerialChannel;
import events.SerialMessage;

/**
 * Questa classe rappresenta il canale di comunicazione seriale osservabile.
 * Si occuperà di ricevere e generare eventi alla ricezione di messaggi sulla seriale.
 *
 */
public class SerialChannelObservable extends BasicObservable {
	
	private final String port;
	private SerialChannel channel;
	
	public SerialChannelObservable(final String port) {
		this.port = port;
	}
	
	public void startListening(final SerialChannel sc) {
		try {
			channel = sc;
			channel.startCommunication(port);
			System.out.println(channel.getAvaiableSerialPorts());
			System.out.println("Waiting Arduino for rebooting...");		
			Thread.sleep(4000);
			System.out.println("Ready.");		
		} catch (final Exception e) {
			e.printStackTrace();
		}
		
		//Creazione del thread deputato all'attesa di messaggi sulla seriale.
		new Thread(() -> {
			while(true) {
				try {
					//Chiamata bloccante, che aspetta un messaggio nella coda di messaggi sulla seriale. 
					//Tale messaggio verrà aggiunto al verificarsi di un evento sualla seriale.
					//Il tutto viene gestito internamente dal canale di comunicazione seriale.
					final String msg = channel.receiveMsg();
					
					//Notifica di eventi della seriale.
					notifyEvent(new SerialMessage(msg));
				} catch (final InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
	}
}
