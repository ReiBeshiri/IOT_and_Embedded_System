package observable;

import java.net.DatagramPacket;

import channel.SocketChannel;
import channel.SocketChannelImpl;
import events.ClientRequest;

/**
 * Canale di comunicazione seriale osservabile.
 * Si occuperà di ricevere e generare eventi alla ricezione di messaggi sulla socket UDP.
 *
 */
public class SocketChannelObservable extends BasicObservable {
	
	private final int port;
	private SocketChannel channel;
	
	public SocketChannelObservable(final int port) {
		this.port = port;
	}
	
	public void startListening() {
		try {
			//Creazione del canale reale sulla socket.
			channel = new SocketChannelImpl();
			channel.startCommunication(port);
		} catch (final Exception e) {
			e.printStackTrace();
		}
		
		//Avvio del thread deputato all'attesa di messaggi sul canale socket.
		new Thread(() -> {
			while(true) {
				//Chiamata bloccante silla receive message del canale socket.
				final DatagramPacket pkt = channel.receiveMsg();
				
				//notifica dell'evento agli observer di una richiesta pervenuta da un client.
				notifyEvent(new ClientRequest(pkt, channel));
			}
		}).start();
	}
}
