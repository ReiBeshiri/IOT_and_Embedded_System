package agent;
 
import events.Event;

/**
 * Interfaccia funzionale utilizzata per specializzare i comportamenti dei vari handler specifici.
 */
public interface Handler {
	void handle(final Event ev);
}
