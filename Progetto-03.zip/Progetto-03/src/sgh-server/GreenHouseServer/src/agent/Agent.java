package agent;

import java.sql.Time;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;
import channel.SerialChannel;
import channel.SerialChannelImpl;
import events.ClientRequest;
import events.Event;
import events.SerialMessage;
import events.TimerEvent;
import io.vertx.core.Vertx;
import observable.Observable;
import observable.SerialChannelObservable;
import observable.SocketChannelObservable;
import observable.TimerObservable;
import utils.Pair;

public class Agent extends EventLoopWithHandlers {

	private final List<Pair<Time, String>> storedData;
	private final SerialChannel sc; // Da passare all'observable all'inizializzazione.
	private final Observable serialObs;
	private final Observable socketObs;
	private final Observable timerObs;
	private final String host;
	private final int portRequest;

	public Agent(final int serverPort, final String serialPort, final long timerPeriod, final String host, final int portRequest) {
		storedData = new LinkedList<Pair<Time,String>>();
		sc = new SerialChannelImpl();
		
		//Creazione observable.
		serialObs = new SerialChannelObservable(serialPort);
		socketObs = new SocketChannelObservable(serverPort);
		timerObs = new TimerObservable();
		
		//Aggiunta agente come observer dei canali/risorse observable creati.
		serialObs.addObserver(this);
		socketObs.addObserver(this);
		timerObs.addObserver(this);
		((SerialChannelObservable) serialObs).startListening(sc);
		((SocketChannelObservable) socketObs).startListening();
		((TimerObservable) timerObs).start(timerPeriod);
		this.host = host;
		this.portRequest = portRequest;
	}
	
	@Override
	protected void setupHandlers() {
		addHandler(SerialMessage.class, (Event e) -> {
			//Handler per la gestione dei messaggi provenenti dalla seriale, si occupa di aggiungerli alla lista dei dati storici.
			final SerialMessage ev = (SerialMessage) e;
			System.out.println(ev.getMessage());
			storedData.add(new Pair<Time, String>(Time.valueOf(LocalTime.now()), ev.getMessage()));
		}).addHandler(ClientRequest.class, (Event e) -> {
			//Handler per la gestione dei messaggi provenienti dal canale socket e quindi dal client.
			//Viene inviata una copia della lista dei dati memorizzati negli stored data al client mediante la socket.
			final ClientRequest ev = (ClientRequest) e;
			final List<Pair<Time, String>> copy = new LinkedList<>(storedData);
			System.out.println("[AGENT] Sending data to client.");
			ev.getSocket().sendMessage(ev.getPacket(), copy);
			storedData.clear();
		}).addHandler(TimerEvent.class, (Event e) -> {
			//Handler per la gestione degli eventi temporali, ogni colta che viene generato un evento dal timer (ogni tot tempo),
			//viene fatta una GET al data service, messo online mediante ngrok, per ottenere aggiornamenti, e i dati raccolti 
			//memorizzati nella lista che raccoglie i dati in attesa di spedirli al client.
			final Vertx vertx = Vertx.vertx();
			vertx.createHttpClient().getNow(portRequest, host, "/api/data", response -> {
				System.out.println("[AGENT] Pulled data from server with status: " + response.statusCode());
				response.bodyHandler(body -> {
					System.out.println("[AGENT] Sending received data to Arduino.");
					int val = body.toJsonArray().getInteger(0);
					sc.sendMessage(Integer.toString(val));
					storedData.add(new Pair<Time, String>(Time.valueOf(LocalTime.now()), "Data read from service: " + Integer.toString(val)));
				});
			});
		});
	}
}
