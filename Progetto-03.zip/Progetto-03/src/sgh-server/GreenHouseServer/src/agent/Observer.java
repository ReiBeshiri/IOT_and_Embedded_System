package agent;

import events.Event;

public interface Observer {
	boolean notifyEvent(final Event ev);
}
