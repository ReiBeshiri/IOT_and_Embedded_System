package agent;

import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;

import events.Event;

public abstract class EventLoopWithHandlers extends EventLoopController {
	
	protected HashMap<Class<?>, Handler> handlers;
	
	protected EventLoopWithHandlers(final int size){
		eventQueue = new ArrayBlockingQueue<Event>(size);
		handlers = new HashMap<>();
	}

	protected EventLoopWithHandlers(){
		this(defaultEventQueueSize);
		setupHandlers();
	}
	
	abstract protected void setupHandlers();
	
	public EventLoopWithHandlers addHandler(final Class<?> evc, final Handler h) {
		handlers.put(evc, h);
		return this;
	}
	
	protected void processEvent(final Event ev) {
		//Vengono utilizzati gli handler pe ril processamento delli eventi.
		//Vengono quindi mappati gli eventi con i rispettivi handler in una fase di setup iniziale, 
		//per poi essere gestiti in base al loro tipo (classe di appartenenza).
		//In questo modo sarà il main thread (agente) a gestire i vari eventi.
		final Handler hnd = handlers.get(ev.getClass());
		if (hnd != null) {
			hnd.handle(ev);
		}
	}
	
}
