package agent;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import events.Event;
import observable.Observable;

public abstract class EventLoopController extends Thread implements Observer {
	
	public static final int defaultEventQueueSize = 50; //Numero massimo di eventi accodabili.
	protected BlockingQueue<Event> eventQueue;		   //Coda che raccoglie eventi.
	
	protected EventLoopController(final int size) {
		eventQueue = new ArrayBlockingQueue<Event>(size);
	}

	protected EventLoopController() {
		this(defaultEventQueueSize);
	}
	
	abstract protected void processEvent(final Event ev);
	
	public void run() {
		//Event loop.
		while (true){
			try {
				Event ev = this.waitForNextEvent();
				this.processEvent(ev);
			} catch (Exception ex){
				//Metodo astratto specializzato dalle sottoclassi.
				ex.printStackTrace();
			}
		}
	}
	
	protected void startObserving(final Observable object) {
		object.addObserver(this);
	}

	protected void stopObserving(final Observable object) {
		object.removeObserver(this);
	}
	
	//Metodo utilizzto per ottenere l'evento successivo. 
	//Non viene fatto busy waiting, perchè viene apsettato fino a quando nella cosa 
	//non sarà presente un evento da servire.
	protected Event waitForNextEvent() throws InterruptedException {
		return eventQueue.take();
	}

	protected Event pickNextEventIfAvail() throws InterruptedException {
		return eventQueue.poll();
	}
	
	public boolean notifyEvent(final Event ev) {
		return eventQueue.offer(ev);
	}
}
