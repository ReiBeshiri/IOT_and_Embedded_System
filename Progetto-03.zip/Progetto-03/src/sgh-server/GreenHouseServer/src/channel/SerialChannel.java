package channel;

import java.util.List;

/**
 * Interface that represent serial communication.
 *
 */
public interface SerialChannel {

	/**
	 * Getter for avaiable ports.
	 * 
	 * @return String List of port.
	 */
	List<String> getAvaiableSerialPorts();

	/**
	 * Send message.
	 * 
	 * @param msg
	 *            message to send.
	 */
	void sendMessage(final String msg);

	/**
	 * Setter for user selected port.
	 * 
	 * @param serialPort
	 *            selected port.
	 */
	void startCommunication(String serialPort);

	/**
	 * Close communication.
	 */
	void closeCommunication();

	/**
	 * To receive a message.
	 * 
	 * Blocking behavior.
	 */
	String receiveMsg() throws InterruptedException;

}
