package channel;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.sql.Time;
import java.util.List;

import utils.Pair;

public class SocketChannelImpl implements SocketChannel {

	private DatagramSocket socket;
	private byte[] buf = new byte[576];

	@Override
	public void startCommunication(int port) {
		try {
			//Apertura della socket sulla porta selezionata.
			socket = new DatagramSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void closeCommunication() {
		socket.close();
	}

	@Override
	public DatagramPacket receiveMsg() {
		final DatagramPacket packet = new DatagramPacket(buf, buf.length);
		try {
			//Chiamata bloccante per la ricezione del messaggio.
			socket.receive(packet);
		} catch (final IOException e) {
			e.printStackTrace();
		}
		return packet;
	}

	@Override
	public void sendMessage(final DatagramPacket pkt, final List<Pair<Time, String>> data) {
		//Invio dei messaggi mediante la socket udp.
		
		//Estrazione dati utili dal pacchetto. (ip, porta).
		final InetAddress address = pkt.getAddress();
        int port = pkt.getPort();
        final StringBuilder dataToSend = new StringBuilder();
        //Creazione delle coppie (tempo-stringa).
        data.forEach(x -> {
        		dataToSend.append(x.getX() + "-->" + x.getY() + ";");
        });
		final byte[] buff = dataToSend.toString().getBytes();
        final DatagramPacket packet = new DatagramPacket(buff, buff.length, address, port);
        	try {
        		//Risposta alla richiesta proveniente dal client.
    			socket.send(packet);
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
	}

}
