package channel;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class SerialChannelImpl implements SerialChannel, SerialPortEventListener {

	private final BlockingQueue<String> queue;
	private SerialPort serialPort;
	private StringBuffer currentMsg;

	public SerialChannelImpl() {
		currentMsg = new StringBuffer("");
		queue = new ArrayBlockingQueue<String>(1000);
	}

	@Override
	public void startCommunication(final String serialPort) {
		this.serialPort = new SerialPort(serialPort);
		this.setUpCommunication();
	}

	@Override
	public List<String> getAvaiableSerialPorts() {
		return Arrays.asList(SerialPortList.getPortNames());
	}

	/**
	 * Override method from interface SerialEventListener.
	 */
	@Override
	public synchronized void serialEvent(final SerialPortEvent event) {
		if (event.isRXCHAR()) {
            try {
        			final String msg = serialPort.readString(event.getEventValue());
        			int index = msg.indexOf("\n");
        			if (index >= 0) {
        				currentMsg.append(msg.substring(0, index));
        				queue.put(currentMsg.toString());
        				currentMsg.setLength(0);
        				if (index + 1 < msg.length()) {
        					currentMsg.append(msg.substring(index + 1)); 
        				}
        			} else {
        				currentMsg.append(msg);
        			}
            } catch (Exception ex) {
            		ex.printStackTrace();
                System.out.println("Error in receiving string from COM-port: " + ex);
            }
        }
	}

	@Override
	public void closeCommunication() {
		try {
			if (serialPort != null) {
				serialPort.removeEventListener();
				serialPort.closePort();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public String receiveMsg() throws InterruptedException {
		return queue.take();
	}

	private void setUpCommunication() {
		try {
			serialPort.openPort();
			serialPort.setParams(SerialPort.BAUDRATE_9600, 
								SerialPort.DATABITS_8, 
								SerialPort.STOPBITS_1,
								SerialPort.PARITY_NONE);

			serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN | 
										 SerialPort.FLOWCONTROL_RTSCTS_OUT);

			serialPort.addEventListener(this);	
			
		} catch (SerialPortException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void sendMessage(final String msg) {
		char[] array = (msg+"\n").toCharArray();
		byte[] bytes = new byte[array.length];
		for (int i = 0; i < array.length; i++){
			bytes[i] = (byte) array[i];
		}
		try {
			synchronized (serialPort) {
				serialPort.writeBytes(bytes);
			}
		} catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
