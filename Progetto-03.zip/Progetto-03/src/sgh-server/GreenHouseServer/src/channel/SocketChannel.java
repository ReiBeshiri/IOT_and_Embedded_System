package channel;

import java.net.DatagramPacket;
import java.sql.Time;
import java.util.List;

import utils.Pair;

/**
 * Interface that represent channel for socket communication.
 *
 */
public interface SocketChannel {

	/**
	 * Setter for selected port.
	 * 
	 * @param port
	 *            selected port.
	 */
	void startCommunication(int port);

	/**
	 * Close communication.
	 */
	void closeCommunication();

	/**
	 * To receive a message.
	 * 
	 * Blocking behavior.
	 */
	DatagramPacket receiveMsg();

	/**
	 * Send data to client.
	 * 
	 * @param pkt
	 *            packet with client info.
	 * @param data
	 *            list of data to send.
	 */
	void sendMessage(final DatagramPacket pkt, final List<Pair<Time, String>> data);
}
