/**
 * Mattia Vincenzi 792970
 * Rei Beshiri     789973
 */
package app;

import agent.Agent;
import io.vertx.core.Vertx;
import service.DataService;


// Avviare ngrock sulla stessa porta su cui avvieremo il DataService (8080) --> Tunnel sicuro.
// Avviare il data service con la porta del data sulla stessa di ngrok (8080).
// Fare richieste al sito di ngrok con una porta qualsiasi (80), ma indirizzate al sito. 
public class App {

	private static final int SERVICE_PORT = 8080;
	private static final int SERVER_PORT = 8888;
	private static final String SERIAL_PORT = "/dev/cu.usbmodem14101";
	private static final long PERIOD = 6100;
	private static final int PORT_REQUEST = 80;
	private static final String HOST = "6a927b6e.ngrok.io";
	
	public static void main(final String[] args) {
		final Vertx vertx = Vertx.vertx();
		final DataService service = new DataService(SERVICE_PORT);
		vertx.deployVerticle(service);
		final Agent agent = new Agent(SERVER_PORT, SERIAL_PORT, PERIOD, HOST, PORT_REQUEST);
		agent.start();
	}

}
