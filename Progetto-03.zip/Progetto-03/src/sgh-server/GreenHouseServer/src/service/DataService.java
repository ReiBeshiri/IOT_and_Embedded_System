package service;

import java.util.Date;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

/*
 * Data Service as a vertx event-loop 
 */
public class DataService extends AbstractVerticle {

	private int port;
	private int value;

	public DataService(final int port) {
		this.port = port;
	}

	@Override
	public void start() {
		final Router router = Router.router(vertx);
		router.route().handler(BodyHandler.create());
		
		//Viene avviato il data service impostando i metodi da eseguire in risposta a richieste HTTP di GET e POST.
		router.post("/api/data").handler(this::handleAddNewData);
		router.get("/api/data").handler(this::handleGetData);
		vertx.createHttpServer().requestHandler(router::accept).listen(port);

		log("Service ready on port " + port + ".");
	}

	private void handleAddNewData(final RoutingContext routingContext) {
		//Routine che viene eseguita quando viene effettuata una richiesta di post.
		final HttpServerResponse response = routingContext.response();
		final JsonObject res = routingContext.getBodyAsJson();
		if (res == null) {
			sendError(400, response);
		} else {
			//Viene impostato il valore attuale disponibile a quello inviato in post.
			int perc = res.getInteger("value");
			value = perc;
			long time = System.currentTimeMillis();
			log("New value: " + value + " on " + new Date(time));
			response.setStatusCode(200).end();
		}
	}

	private void handleGetData(final RoutingContext routingContext) {
		//Routine eseguita a seguito di una richiesta get.
		final JsonArray response = new JsonArray();
		response.add(value);
		log("Response: " + response);
		routingContext.response()
					  .putHeader("content-type", "application/json")
					  .end(response.encodePrettily());
	}

	private void sendError(final int statusCode, final HttpServerResponse response) {
		response.setStatusCode(statusCode).end();
	}

	private void log(final String msg) {
		System.out.println("[DATA SERVICE] " + msg);
	}
}
