package channel;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;

import gui.GUI;

public class SocketChannelImpl implements SocketChannel {

	private DatagramSocket socket;
	private byte[] buf = new byte[576]; //max buffer dim per un socket udp
	private int serverPort;
	private InetAddress address;
	private GUI gui;

	public SocketChannelImpl(final int port) {
		serverPort = port;
	}
	
	@Override
	public void startCommunication() {
		try {
			//Viene creata una socket UDP e impostato come indirizzo di destinazione localhost.
			socket = new DatagramSocket();
			address = InetAddress.getByName("localhost");
			System.out.println("[CLIENT] Starting communication with server...");
			Thread.sleep(1000);
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void closeCommunication() {
		socket.close();
	}

	@Override
	public void getUpdates() {
        try {
        		//Viene mandata una richiesta di aggiornamento (pacchetto vuoto) al server.
        		DatagramPacket packet = new DatagramPacket(buf, buf.length, address, serverPort);
			socket.send(packet);
			System.out.println("[CLIENT] Sent request to server for updates.");
			packet = new DatagramPacket(buf, buf.length);
			
			//Metodo bloccante che aspetta la risposta da parte del server.
	        socket.receive(packet);
	        
	        //Lettura del payload dei dati ricevuti ed aggiornamento della GUI.
	        final String received = new String(packet.getData(), 0, packet.getLength());
	        System.out.println("[CLIENT] Received msg from server: " + received);
	        Arrays.asList(received.split(";")).forEach(x -> gui.displayMessage(x));
	        
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setGuiRef(final GUI gui) {
		this.gui = gui;
	}

}
