package channel;

import gui.GUI;

public interface SocketChannel {

	/**
	 * Start communication throw socket channel
	 */
	void startCommunication();

	/**
	 * Close communication.
	 */
	void closeCommunication();

	/**
	 * Get updates from server.
	 */
	void getUpdates();

	/**
	 * Setter for gui reference.
	 * 
	 * @param gui
	 */
	void setGuiRef(final GUI gui);
}
