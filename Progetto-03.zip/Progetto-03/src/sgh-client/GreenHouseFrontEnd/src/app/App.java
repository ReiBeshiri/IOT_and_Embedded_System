/**
 * Mattia Vincenzi 792970
 * Rei Beshiri     789973
 */
package app;

import channel.SocketChannel;
import channel.SocketChannelImpl;
import gui.GUIImpl;

public class App {

	private static final int SERVER_PORT = 8888;
	private static final int PERIOD = 1000; //Millis to wait for updates.
	
	public static void main(String[] args) {
		final SocketChannel channel = new SocketChannelImpl(SERVER_PORT);
		
		//Come secondo parametro alla GUI viene passato il corpo del thread che si occuperà
		//delle richieste di aggiornamenro al server.
		new GUIImpl(channel, ()-> {
			while(true) {
				try {
					Thread.sleep(PERIOD);
					channel.getUpdates();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).initUI();
	}

}
