package gui;

public interface GUI {
	/**
	 * Display message.
	 * 
	 * @param msg
	 *            message to display.
	 */
	void displayMessage(final String msg);
	
	/**
	 * Initialize gui.
	 */
	void initUI();
}
