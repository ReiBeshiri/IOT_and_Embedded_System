package gui;

import java.awt.BorderLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import channel.SocketChannel;

public class GUIImpl implements GUI {

	private SocketChannel channel;
	private JList<String> msgList;
	private Runnable runnable;
	private DefaultListModel<String> model;

	/**
	 * Constructor for GUI.
	 * 
	 * @param channel
	 *            socket channel ref.
	 * @param runnable
	 *            runnable that is the body of updater thread.
	 */
	public GUIImpl(final SocketChannel channel, final Runnable runnable) {
		this.channel = channel;
		this.runnable = runnable;
		model = new DefaultListModel<>();
	}

	@Override
	public void displayMessage(final String msg) {
		SwingUtilities.invokeLater(() -> model.addElement(msg));
	}

	@Override
	public void initUI() {
		final JFrame frame = new JFrame("GreenHouseFrontEnd");

		final JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());

		final JButton button = new JButton("Close");
		final JScrollPane scroll = new JScrollPane();
		msgList = new JList<>(model);
		scroll.setViewportView(msgList);
		panel.add(button, BorderLayout.SOUTH);
		panel.add(scroll, BorderLayout.CENTER);

		frame.add(panel);
		frame.setSize(500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		//Viene avviato il thread che si occuperà delle richieste di aggiornamento.
		channel.setGuiRef(this);
		channel.startCommunication();
		final Thread thread = new Thread(() -> runnable.run());
		thread.setDaemon(true);
		thread.start();
	}
}
