function sendData(content) {
  var options = {
    host: '29d845c7.ngrok.io',
    port: '80',
    path:'/api/data',
    method:'POST',
    headers: {
      "Content-Type":"application/json",
      "Content-Length":content.length
    }
  };
  console.log("Sending " + content + "...");

  //Richiesta modulo http per inviare dati.
  //option --> abbiamo creato un oggetto da inviare (header) tramite http con tutte le informazioni necessarie
  //all'invio al server su ngrok.
  //La funzione è la callback (prog asincrona).
  //La end serve per terminare l'invio dell'header del pacchetto e inviate il payload.
  require("http").request(options, function(res) {
    res.on('close', function(data) {
      console.log("OK."); //Alla chiusura stampa OK.
    });
  }).end(content); //Invio dati in json passati come parametro.
};

function doJob() {
  //Settiamo la funzione da richiamare periodicamente ogni 6 secondi circa.
  setInterval(function(){
    var value = Math.round(analogRead(A0)*100); //Vogliamo umidità in percentuale.
    sendData('{ "value": ' + value + '}');
  },6000);
}

//Setup del Wifi.
var wifi = require("Wifi"); //Richiesta modulo Wifi.

//Settare wifi telefono.
wifi.connect("iPhone", {password:"seiot1819"}, function(err) { //Callback
  if (err == null){
    console.log("connected: ", wifi.getIP());
    doJob();
  } else {
    console.log("error - not connected.");
  }
});
